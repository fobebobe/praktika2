import mongoose from "mongoose";
import { Cart } from "./cart.mjs"; // Импортируем модель Cart


const userSchema = new mongoose.Schema({
    username:{
        type:String,
        required:true,
    },
    email: {
        type:String,
        required:true,
    },
    password:{
        type:String,
        required:true
    },
    phoneNumber: {
        type: String,
        required: false,
    },
    clubCard: {
        type: mongoose.Schema.Types.ObjectId,
        ref:"Card",
        required: true,
        unique: true,
    }
}, {
    timestamps: true, // Добавляет поля createdAt и updatedAt
});

// Хук для каскадного удаления корзины при удалении пользователя
userSchema.pre('remove', async function (next) {
    const user = this; // Текущий документ пользователя

    try {
        // Удаляем все корзины, связанные с этим пользователем
        await Cart.deleteMany({ userId: user._id });
        next();
    } catch (error) {
        return next(error);
    }
});

export const User = mongoose.model('User', userSchema);

