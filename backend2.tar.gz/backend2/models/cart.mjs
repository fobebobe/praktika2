import mongoose from "mongoose";

const cartItemSchema = new mongoose.Schema({
    productId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Products', // Ссылка на модель Products
        required: true,
    },
    quantity: {
        type: Number,
        required: true,
        min: 1, // Количество товаров не может быть меньше 1
    },
});

const cartSchema = new mongoose.Schema({
    userId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User', // Ссылка на модель User (если есть авторизация)
        required: true,
    },
    items: [cartItemSchema], // Массив товаров в корзине
    totalPrice: {
        type: Number,
        required: true,
        default: 0,
    },
    totalQuantity: {
        type: Number,
        required: true,
        default: 0,
    },
});

export const Cart = mongoose.model('Cart', cartSchema);