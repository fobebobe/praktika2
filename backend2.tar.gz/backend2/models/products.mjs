
import mongoose from "mongoose";

const productsSchema = new mongoose.Schema({

    name:{
        type:String,
        required:true
    },

    author:{
        type:String,
        required:true
    },

    price:{
        type:String,
        required:true
    },
    stock: {
        type: Number,
        required: true,
        min: 0, // Количество товаров в наличии не может быть отрицательным
    }

})

export const Products = mongoose.model('Products', productsSchema);