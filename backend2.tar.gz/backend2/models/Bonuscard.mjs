
import mongoose from "mongoose";

const cardSchema = new mongoose.Schema({
    bonusCount:{
        type:String,
        required:true
    }
});

export const Card = mongoose.model('Card',cardSchema);