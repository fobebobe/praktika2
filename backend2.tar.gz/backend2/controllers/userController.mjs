import { User } from "../models/User.mjs";
import bcrypt from "bcrypt";
import jwt from 'jsonwebtoken';
import Joi from "joi";
import { configDotenv } from 'dotenv';

configDotenv();

export default class UserController {

     // Схема валидации для метода create
     static createValidationSchema = Joi.object({
        username: Joi.string().required().min(3).max(30).messages({
            'string.base': 'Имя пользователя должно быть строкой',
            'string.empty': 'Имя пользователя обязательно',
            'string.min': 'Имя пользователя должно быть не менее {#limit} символов',
            'string.max': 'Имя пользователя должно быть не более {#limit} символов',
        }),
        email: Joi.string().required().email().messages({
            'string.base': 'Email должен быть строкой',
            'string.empty': 'Email обязателен',
            'string.email': 'Неверный формат email',
        }),
        password: Joi.string().required().min(6).messages({
            'string.base': 'Пароль должен быть строкой',
            'string.empty': 'Пароль обязателен',
            'string.min': 'Пароль должен быть не менее {#limit} символов',
        }),
        phoneNumber: Joi.string()
            .required()
            .pattern(/^\+?\d{10,14}$/) // Проверка формата номера телефона
            .messages({
                'string.base': 'Номер телефона должен быть строкой',
                'string.empty': 'Номер телефона обязателен',
                'string.pattern.base': 'Неверный формат номера телефона. Пример: +1234567890 или 1234567890',
            }),
            clubCard: Joi.string().required().messages({ // Добавляем поле clubCard
                'string.base': 'Номер клубной карты должен быть строкой',
                'string.empty': 'Номер клубной карты обязателен',
            })
    });

    // Схема валидации для метода login
    static loginValidationSchema = Joi.object({
        email: Joi.string().required().email().messages({
            'string.base': 'Email должен быть строкой',
            'string.empty': 'Email обязателен',
            'string.email': 'Неверный формат email',
        }),
        password: Joi.string().required().messages({
            'string.base': 'Пароль должен быть строкой',
            'string.empty': 'Пароль обязателен',
        }),
    });

    static async create(req, res) {
        try {
            // Валидация данных
            const { error } = UserController.createValidationSchema.validate(req.body, { abortEarly: false });
            if (error) {
                return res.status(400).json({ errors: error.details });
            }

            const { username, email, password, phoneNumber, clubCard } = req.body;
            const hashed = await bcrypt.hash(password, 5);
            const user = new User({
                email,
                username,
                password: hashed,
                phoneNumber,
                clubCard
            });
            await user.save();
            return res.status(201).json({ msg: 'Создан' });
        } catch (error) {
            console.log(error);
            return res.status(500).json({ error });
        }
    }

    static async login(req, res) {
        try {
            // Валидация данных
            const { error } = UserController.loginValidationSchema.validate(req.body, { abortEarly: false });
            if (error) {
                return res.status(400).json({ errors: error.details });
            }

            const { email, password } = req.body;

            // Найти пользователя по email
            const user = await User.findOne({ email: email });
            if (!user) {
                return res.status(404).json({ msg: 'Пользователь не найден' });
            }

            // Проверка схожести пароля
            const isPasswordMatch = await bcrypt.compare(password, user.password);
            if (!isPasswordMatch) {
                return res.status(401).json({ msg: 'Неверный пароль' });
            }

            // Создание JWT-токена
            const payload = {
                _id: user._id,
                username: user.username,
            };
            const token = await jwt.sign(payload, process.env.SECRET, { expiresIn: '10h' });

            // Возвращение данных пользователя и токена
            return res.status(200).json({ ...user._doc, token });
        } catch (error) {
            console.error(error);
            return res.status(500).json({ error: 'Внутренняя ошибка сервера' });
        }
    }



//    Получение пользователя по id
    static async getUserById(req, res) {    
        try {
            const { id } = req.params;
            const user = await User.findById(id);
            if (!user) {
                return res.status(404).json({ msg: 'Пользователь не найден' });
            }
            return res.status(200).json(user);
        } catch (error) {
            return res.status(500).json({ error });
        }
    }

 
    static async getUserByName(req, res) {
        try {
            const { username } = req.params; // Получаем username из параметров запроса
            const user = await User.findOne({ username }); // Ищем пользователя по username

            if (!user) {
                return res.status(404).json({ msg: 'Пользователь не найден' });
            }

            return res.status(200).json(user); // Возвращаем всю информацию о пользователе
        } catch (error) {
            console.error('Ошибка при поиске пользователя:', error);
            return res.status(500).json({ error: 'Ошибка сервера' });
        }
    }


    // Обновление пользователя
    static async updateUser(req, res) {
        try {
            const { id } = req.params; // Получаем ID пользователя из параметров запроса
            const { username, email, password } = req.body; // Получаем данные для обновления из тела запроса
    
            // Проверяем, существует ли пользователь с указанным ID
            const user = await User.findById(id);
            if (!user) {
                return res.status(404).json({ msg: 'Пользователь не найден' });
            }
    
            // Хешируем пароль, если он предоставлен
            let hashedPassword = user.password;
            if (password) {
                hashedPassword = await bcrypt.hash(password, 5);
            }
    
            // Обновляем данные пользователя
            const updatedUser = await User.findByIdAndUpdate(
                id,
                {
                    username: username || user.username, // Обновляем имя пользователя, если оно предоставлено
                    email: email || user.email, // Обновляем email, если он предоставлен
                    password: hashedPassword // Обновляем пароль, если он предоставлен
                },
                { new: true } // Возвращаем обновлённый документ
            );
    
            return res.status(200).json(updatedUser);
        } catch (error) {
            console.log(error);
            return res.status(500).json({ error: 'Ошибка сервера' });
        }
    }
       // Удаление пользователя
       static async deleteUser(req, res) {
        try {
            const { id } = req.params;

            // Проверка существования пользователя
            const user = await User.findById(id);
            if (!user) {
                return res.status(404).json({ msg: 'Пользователь не найден' });
            }

            // Удаление пользователя и связанных корзин
            await user.remove();

            return res.status(200).json({ msg: 'Пользователь и его корзина успешно удалены' });
        } catch (error) {
            console.log(error);
            return res.status(500).json({ error: 'Ошибка сервера' });
        }
    }
}


