import bcrypt from "bcrypt";
import jwt from 'jsonwebtoken';
import Joi from "joi";
import { configDotenv } from 'dotenv';
import { Card } from "../models/Bonuscard.mjs";

configDotenv();

export default class CardController {
    static createCardValidationSchema = Joi.object({
        bonusCount: Joi.number().required().min(0).messages({
            'number.base': 'Количество бонусов должно быть числом',
            'number.empty': 'Количество бонусов обязательно',
            'number.min': 'Количество бонусов не может быть отрицательным',
        }),
    });

    static updateCardValidationSchema = Joi.object({
        bonusCount: Joi.number().min(0).messages({
            'number.base': 'Количество бонусов должно быть числом',
            'number.min': 'Количество бонусов не может быть отрицательным',
        }),
    });

    static async createCard(req, res) {
        try {
            const { error } = CardController.createCardValidationSchema.validate(req.body, { abortEarly: false });
            if (error) {
                return res.status(400).json({ errors: error.details });
            }

            const { bonusCount } = req.body;
            const card = new Card({
                bonusCount,
            });
            await card.save();
            return res.status(201).json({ msg: 'Карта успешно создана' });
        } catch (error) {
            console.log(error);
            return res.status(500).json({ error: 'Ошибка сервера' });
        }
    }

    static async getCardById(req, res) {
        try {
            const { id } = req.params;
            const card = await Card.findById(id);
            if (!card) {
                return res.status(404).json({ msg: 'Карта не найдена' });
            }
            return res.status(200).json(card);
        } catch (error) {
            return res.status(500).json({ error: 'Ошибка сервера' });
        }
    }

    static async updateCard(req, res) {
        try {
            const { error } = CardController.updateCardValidationSchema.validate(req.body, { abortEarly: false });
            if (error) {
                return res.status(400).json({ errors: error.details });
            }

            const { id } = req.params;
            const { bonusCount } = req.body;

            const card = await Card.findById(id);
            if (!card) {
                return res.status(404).json({ msg: 'Карта не найдена' });
            }

            const updatedCard = await Card.findByIdAndUpdate(
                id,
                {
                    bonusCount: bonusCount || card.bonusCount,
                },
                { new: true }
            );

            return res.status(200).json(updatedCard);
        } catch (error) {
            console.log(error);
            return res.status(500).json({ error: 'Ошибка сервера' });
        }
    }

    static async deleteCard(req, res) {
        try {
            const { id } = req.params;

            const card = await Card.findById(id);
            if (!card) {
                return res.status(404).json({ msg: 'Карта не найдена' });
            }

            await Card.findByIdAndDelete(id);

            return res.status(200).json({ msg: 'Карта успешно удалена' });
        } catch (error) {
            console.log(error);
            return res.status(500).json({ error: 'Ошибка сервера' });
        }
    }
}