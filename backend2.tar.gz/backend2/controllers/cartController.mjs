import Joi from "joi";
import { Cart } from "../models/cart.mjs";
import { Products } from "../models/products.mjs";

export default class CartController {
    static addToCartValidationSchema = Joi.object({
        productId: Joi.string().required().messages({
            'string.empty': 'ID товара обязателен',
        }),
        quantity: Joi.number().required().min(1).messages({
            'number.base': 'Количество должно быть числом',
            'number.min': 'Количество должно быть не менее 1',
        }),
    });

    static async addToCart(req, res) {
        try {
            const { error } = CartController.addToCartValidationSchema.validate(req.body, { abortEarly: false });
            if (error) {
                return res.status(400).json({ errors: error.details });
            }

            const { productId, quantity } = req.body;
            const userId = req.user._id; // Предполагается, что пользователь авторизован

            // Найти товар по ID
            const product = await Products.findById(productId);
            if (!product) {
                return res.status(404).json({ msg: 'Товар не найден' });
            }

            // Найти корзину пользователя
            let cart = await Cart.findOne({ userId });

            if (!cart) {
                // Если корзина не существует, создать новую
                cart = new Cart({
                    userId,
                    items: [],
                    totalPrice: 0,
                    totalQuantity: 0,
                });
            }

            // Проверить, есть ли товар уже в корзине
            const existingItem = cart.items.find(item => item.productId.equals(productId));

            if (existingItem) {
                // Если товар уже есть, увеличить количество
                existingItem.quantity += quantity;
            } else {
                // Если товара нет, добавить новый элемент
                cart.items.push({ productId, quantity });
            }

            // Пересчитать итоговую сумму и количество товаров
            cart.totalPrice = cart.items.reduce((total, item) => {
                return total + item.quantity * product.price;
            }, 0);

            cart.totalQuantity = cart.items.reduce((total, item) => {
                return total + item.quantity;
            }, 0);

            await cart.save();

            return res.status(200).json({ msg: 'Товар добавлен в корзину', cart });
        } catch (error) {
            console.log(error);
            return res.status(500).json({ error: 'Ошибка сервера' });
        }
    }

    static async getCart(req, res) {
        try {
            const userId = req.user._id; // Предполагается, что пользователь авторизован

            const cart = await Cart.findOne({ userId }).populate('items.productId');

            if (!cart) {
                return res.status(404).json({ msg: 'Корзина пуста' });
            }

            return res.status(200).json(cart);
        } catch (error) {
            console.log(error);
            return res.status(500).json({ error: 'Ошибка сервера' });
        }
    }

    static async removeFromCart(req, res) {
        try {
            const { productId } = req.params;
            const userId = req.user._id; // Предполагается, что пользователь авторизован

            const cart = await Cart.findOne({ userId });

            if (!cart) {
                return res.status(404).json({ msg: 'Корзина пуста' });
            }

            // Удалить товар из корзины
            cart.items = cart.items.filter(item => !item.productId.equals(productId));

            // Пересчитать итоговую сумму и количество товаров
            const product = await Products.findById(productId);
            if (product) {
                cart.totalPrice = cart.items.reduce((total, item) => {
                    return total + item.quantity * product.price;
                }, 0);

                cart.totalQuantity = cart.items.reduce((total, item) => {
                    return total + item.quantity;
                }, 0);
            } else {
                cart.totalPrice = 0;
                cart.totalQuantity = 0;
            }

            await cart.save();

            return res.status(200).json({ msg: 'Товар удален из корзины', cart });
        } catch (error) {
            console.log(error);
            return res.status(500).json({ error: 'Ошибка сервера' });
        }
    }
}