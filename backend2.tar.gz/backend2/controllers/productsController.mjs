import bcrypt from "bcrypt";
import jwt from 'jsonwebtoken';
import Joi from "joi";
import { configDotenv } from 'dotenv';
import { Products } from "../models/products.mjs";

configDotenv();

export default class ProductsController {
    static createProductsValidationSchema = Joi.object({
        name: Joi.string().required().messages({
            'string.base': 'Название должно быть строкой',
            'string.empty': 'Название обязательно',
        }),
        author: Joi.string().required().messages({
            'string.base': 'Автор должен быть строкой',
            'string.empty': 'Автор обязателен',
        }),
        price: Joi.number().required().min(0).messages({
            'number.base': 'Цена должна быть числом',
            'number.empty': 'Цена обязательна',
            'number.min': 'Цена не может быть отрицательной',
        }),
    });

    static updateProductsValidationSchema = Joi.object({
        name: Joi.string().messages({
            'string.base': 'Название должно быть строкой',
        }),
        author: Joi.string().messages({
            'string.base': 'Автор должен быть строкой',
        }),
        price: Joi.number().min(0).messages({
            'number.base': 'Цена должна быть числом',
            'number.min': 'Цена не может быть отрицательной',
        }),
    });

    static async createProducts(req, res) {
        try {
            const { error } = ProductsController.createProductsValidationSchema.validate(req.body, { abortEarly: false });
            if (error) {
                return res.status(400).json({ errors: error.details });
            }

            const { name, author, price } = req.body;
            const products = new Products({
                name,
                author,
                price
            });
            await products.save();
            return res.status(201).json({ msg: 'Товар успешно создан' });
        } catch (error) {
            console.log(error);
            return res.status(500).json({ error: 'Ошибка сервера' });
        }
    }

    static async getProductsById(req, res) {
        try {
            const { id } = req.params;
            const products = await Products.findById(id);
            if (!Products) {
                return res.status(404).json({ msg: 'Товар не найден' });
            }
            return res.status(200).json(products);
        } catch (error) {
            return res.status(500).json({ error: 'Ошибка сервера' });
        }
    }

    static async updateProducts(req, res) {
        try {
            const { error } = ProductsController.updateProductsValidationSchema.validate(req.body, { abortEarly: false });
            if (error) {
                return res.status(400).json({ errors: error.details });
            }

            const { id } = req.params;
            const { name } = req.body;
            const { author } = req.body;
            const { price } = req.body;


            const products = await Products.findById(id);
            if (!products) {
                return res.status(404).json({ msg: 'Товар не найден' });
            }

            const updatedProducts = await Products.findByIdAndUpdate(
                id,
                {
                    name: name || products.name,
                    author: author || products.author,
                    price: price || products.price
                },
                { new: true }
            );

            return res.status(200).json(updatedProducts);
        } catch (error) {
            console.log(error);
            return res.status(500).json({ error: 'Ошибка сервера' });
        }
    }

    static async deleteProducts(req, res) {
        try {
            const { id } = req.params;

            const products = await Products.findById(id);
            if (!products) {
                return res.status(404).json({ msg: 'Товар не найден' });
            }

            await Products.findByIdAndDelete(id);

            return res.status(200).json({ msg: 'Товар успешно удален' });
        } catch (error) {
            console.log(error);
            return res.status(500).json({ error: 'Ошибка сервера' });
        }
    }
}