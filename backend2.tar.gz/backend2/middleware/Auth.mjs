import jwt from 'jsonwebtoken';

const AuthMidleware = (req, res, next) => { 
    const token = req.header('Authorization')?.split(' ')[1]; 

    if (!token) {
        return res.status(401).json({ msg: 'Отсутствует токен авторизации' });
    }

    try {
        const decoded = jwt.verify(token, process.env.SECRET); 
        req.user = decoded; 
        next();
    } catch (error) {
        if (error.name === 'TokenExpiredError') {
            return res.status(401).json({ msg: 'Срок действия токена истек' });
        }
        return res.status(401).json({ msg: 'Недействительный токен' });
    }
};

export { AuthMidleware };