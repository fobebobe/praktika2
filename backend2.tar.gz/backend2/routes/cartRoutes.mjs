import { Router } from "express";
import CartController from "../controllers/cartController.mjs";
import { AuthMidleware } from "../middleware/Auth.mjs";

const cartRouter = Router();

// Добавить товар в корзину
cartRouter.post('/add', AuthMidleware, CartController.addToCart);

// Получить корзину пользователя
cartRouter.get('/', CartController.getCart);

// Удалить товар из корзины
cartRouter.delete('/remove/:productId', CartController.removeFromCart);
    
export default cartRouter;