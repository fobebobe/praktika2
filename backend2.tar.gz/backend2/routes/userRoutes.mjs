import { Router } from "express";
import UserController from "../controllers/userController.mjs";
import { AuthMidleware } from "../middleware/Auth.mjs";



const userRouter = Router();
userRouter.post('/create', UserController.create);
userRouter.post('/login',UserController.login);
userRouter.get('/user/:id', UserController.getUserById);
userRouter.get('/user/:username', UserController.getUserByName);
userRouter.put('/:id',UserController.updateUser);
userRouter.delete('/:id',UserController.deleteUser);




export default userRouter;