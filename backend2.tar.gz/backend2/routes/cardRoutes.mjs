import { Router } from "express";
import CardController from "../controllers/cardController.mjs";




const cardRouter = Router();
cardRouter.post('/createcard', CardController.createCard);
cardRouter.get('/:id', CardController.getCardById);
cardRouter.put('/:id',CardController.updateCard);
cardRouter.delete('/:id',CardController.deleteCard);




export default cardRouter;