import { Router } from "express";

import ProductsController from "../controllers/productsController.mjs";

const productsRouter = Router();
productsRouter.post('/createProducts', ProductsController.createProducts);
productsRouter.get('/:id', ProductsController.getProductsById);
productsRouter.put('/:id',ProductsController.updateProducts);
productsRouter.delete('/:id',ProductsController.deleteProducts);




export default productsRouter;