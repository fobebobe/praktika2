import express from 'express';
import cors from 'cors';
import connectDB from './config/connect_db.mjs';
import router from './routes/index.mjs';
import userRoutes from './routes/userRoutes.mjs'
import cardRoutes from './routes/cardRoutes.mjs';
import productsRouter from './routes/productsRoutes.mjs';
import cartRouter from './routes/cartRoutes.mjs';

connectDB();
const app = express();

app.use(cors());
app.use(express.json());
app.use(router);
app.use('/api', userRoutes);
app.use('/card',cardRoutes);
app.use('/products',productsRouter)
app.use('/cart',cartRouter)


app.listen(process.env.PORT,(err)=> err ? console.log(err) : console.log(`The server started localhost ${process.env.PORT}`));